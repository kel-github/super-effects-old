EFIL Study Data - READ ME

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for Kelly Garner - the effect of sample sizes on effect sizes study
08 August 2019
created by Abbey S Nydam

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Tasks

OSpan
AB
GNG
SD
VSL
CC - Contextual Cuing
SRT - Serial Reaction Time Task

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Files

Subject by conditions for: AB, CC, SD, SRT, VSL
Subject by index (1 variable per task, no conditions) in aggregate data file for: OSpan, GNG (commission errors) and VSL

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Learning Effects

CC - ANOVA on RTs for DISPLAY TYPE (repeat vs novel) by Block (1 - 12) or can collapse into epochs (1 to 4)

SRT - t-test on accuracy for sequence block 3 vs random block 4

SD - t-test on single task RTs vs dual task RTs

AB - t-test on accuracy (Target 2 | Target 1) for short lag (1 and 2) vs long lag (5 and 7)

VSL - one sample t-test against chance (.5) for accuracy

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Demographic codes

Female = 1
Glasses or contacts = 1

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

For more information contact: abbey.nydam@gmail.com

:)



